import About from "./components/About";
import AmbientBackground from "./components/AmbientBackground";
import Contact from "./components/Contact";
import Hero from "./components/Hero";
import Navbar from "./components/Navbar";
import Projects from "./components/Projects";
import SectionTransition from "./components/SectionTransition";
import Services from "./components/Services";

function App() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-zinc-950">
      <AmbientBackground />

      <div className="relative z-10">
        <Navbar />

        <Hero />

        <SectionTransition from="purple" />

        <Services />

        <SectionTransition from="blue" />

        <Projects />

        <SectionTransition from="cyan" />

        <About />

        <SectionTransition from="purple" />

        <Contact />
      </div>
    </div>
  );
}

export default App;