import { motion } from "motion/react";
import ScrollReveal from "./ScrollReveal";

function ArrowIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      className="h-4 w-4"
    >
      <path d="M5 12h13" />
      <path d="m13 6 6 6-6 6" />
    </svg>
  );
}

function ExternalIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      className="h-4 w-4"
    >
      <path d="M14 5h5v5" />
      <path d="m19 5-8 8" />
      <path d="M19 13v5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" />
    </svg>
  );
}

function Projects() {
  return (
    <section
      id="projects"
      className="relative overflow-hidden bg-zinc-950 px-6 py-32 text-white"
    >
      {/* Grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.025]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
          backgroundSize: "80px 80px",
        }}
      />

      {/* Ambient glow */}
      <motion.div
        animate={{
          x: [0, 80, -40, 0],
          y: [0, -40, 30, 0],
          scale: [1, 1.1, 0.95, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="pointer-events-none absolute -right-64 top-1/4 h-[650px] w-[650px] rounded-full bg-blue-500/[0.055] blur-[130px]"
      />

      <motion.div
        animate={{
          x: [0, -60, 40, 0],
          y: [0, 40, -30, 0],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="pointer-events-none absolute -left-64 bottom-0 h-[550px] w-[550px] rounded-full bg-purple-500/[0.045] blur-[120px]"
      />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* Header */}
        <ScrollReveal
          delay={0.1}
          distance={50}
        >
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <div>
              <div className="mb-6 flex items-center gap-3">
                <span className="h-px w-8 bg-blue-400/50" />

                <span className="text-[10px] font-medium uppercase tracking-[0.35em] text-zinc-600">
                  Selected Work
                </span>
              </div>

              <h2 className="max-w-3xl text-4xl font-bold tracking-[-0.04em] sm:text-5xl lg:text-6xl">
                Built for
                <span className="block bg-gradient-to-r from-white via-zinc-300 to-zinc-600 bg-clip-text text-transparent">
                  the real world.
                </span>
              </h2>
            </div>

            <div className="flex items-center gap-3 text-sm text-zinc-600">
              <span>01</span>
              <span className="h-px w-10 bg-zinc-800" />
              <span>01</span>
            </div>
          </div>
        </ScrollReveal>

        {/* Project showcase */}
        <ScrollReveal
          delay={0.2}
          distance={70}
          className="mt-16"
        >
          <motion.article
            whileHover="hover"
            className="group relative overflow-hidden rounded-[2rem] border border-zinc-800/80 bg-zinc-900/30 backdrop-blur-xl"
          >
            {/* Top label */}
            <div className="flex items-center justify-between border-b border-zinc-800/80 px-6 py-4 sm:px-8">
              <div className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.7)]" />

                <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500">
                  Live Project
                </span>
              </div>

              <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-700">
                Product 01
              </span>
            </div>

            {/* Visual */}
            <div className="relative overflow-hidden px-4 pt-4 sm:px-8 sm:pt-8">
              {/* Glow */}
              <motion.div
                variants={{
                  hover: {
                    opacity: 0.8,
                    scale: 1.08,
                  },
                }}
                transition={{
                  duration: 0.7,
                }}
                className="pointer-events-none absolute left-1/2 top-1/2 h-[65%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-blue-500/[0.08] blur-[100px]"
              />

              {/* Browser */}
              <motion.div
                initial={{
                  opacity: 0,
                  y: 45,
                  scale: 0.96,
                }}
                whileInView={{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                }}
                viewport={{
                  once: false,
                  amount: 0.3,
                }}
                variants={{
                  hover: {
                    y: -8,
                    scale: 1.012,
                  },
                }}
                transition={{
                  duration: 0.9,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="relative mx-auto max-w-6xl overflow-hidden rounded-t-[1.5rem] border border-zinc-700/60 bg-zinc-950 shadow-2xl shadow-black/50"
              >
                {/* Browser chrome */}
                <div className="flex h-10 items-center gap-2 border-b border-zinc-800 px-4">
                  <span className="h-2 w-2 rounded-full bg-red-400/50" />
                  <span className="h-2 w-2 rounded-full bg-yellow-400/50" />
                  <span className="h-2 w-2 rounded-full bg-green-400/50" />

                  <div className="mx-auto flex h-5 w-1/2 items-center justify-center rounded-md border border-zinc-800 bg-zinc-900">
                    <span className="text-[7px] text-zinc-700">
                      godsownroute.netlify.app
                    </span>
                  </div>
                </div>

                {/* Screenshot */}
                <div className="relative overflow-hidden bg-zinc-900">
                  <motion.img
                    src="/godsownroute.png"
                    alt="GodsOwnRoute Kerala tourism website"
                    variants={{
                      hover: {
                        scale: 1.025,
                      },
                    }}
                    transition={{
                      duration: 0.8,
                      ease: "easeOut",
                    }}
                    className="block h-auto w-full object-cover"
                  />

                  {/* Screen reflection */}
                  <motion.div
                    initial={{
                      x: "-120%",
                    }}
                    whileInView={{
                      x: "120%",
                    }}
                    viewport={{
                      once: false,
                      amount: 0.3,
                    }}
                    transition={{
                      duration: 1.6,
                      delay: 0.5,
                      ease: "easeInOut",
                    }}
                    className="pointer-events-none absolute inset-y-0 w-1/4 skew-x-[-18deg] bg-gradient-to-r from-transparent via-white/[0.06] to-transparent blur-xl"
                  />

                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-zinc-950/20 via-transparent to-white/[0.02]" />
                </div>
              </motion.div>

              {/* Floating tech badge */}
              <motion.div
                initial={{
                  opacity: 0,
                  x: -25,
                  y: 10,
                }}
                whileInView={{
                  opacity: 1,
                  x: 0,
                  y: 0,
                }}
                viewport={{
                  once: false,
                  amount: 0.35,
                }}
                transition={{
                  duration: 0.7,
                  delay: 0.5,
                }}
                variants={{
                  hover: {
                    y: -5,
                  },
                }}
                className="absolute bottom-8 left-8 hidden rounded-2xl border border-zinc-800 bg-zinc-950/90 px-4 py-3 shadow-xl backdrop-blur-xl sm:block"
              >
                <div className="text-[9px] uppercase tracking-[0.2em] text-zinc-700">
                  Stack
                </div>

                <div className="mt-1 text-xs text-zinc-400">
                  React · TypeScript · Tailwind
                </div>
              </motion.div>
            </div>

            {/* Project information */}
            <div className="grid gap-10 p-7 sm:p-10 lg:grid-cols-[1fr_auto] lg:items-end">
              <div>
                <motion.div
                  initial={{
                    opacity: 0,
                    y: 20,
                  }}
                  whileInView={{
                    opacity: 1,
                    y: 0,
                  }}
                  viewport={{
                    once: false,
                    amount: 0.4,
                  }}
                  transition={{
                    duration: 0.6,
                    delay: 0.15,
                  }}
                >
                  <div className="text-xs uppercase tracking-[0.25em] text-zinc-700">
                    Kerala Tourism
                  </div>

                  <h3 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
                    GodsOwnRoute
                  </h3>

                  <p className="mt-4 max-w-2xl text-sm leading-7 text-zinc-500 sm:text-base">
                    A modern Kerala tourism experience designed to
                    help travelers discover destinations, experiences,
                    and places worth exploring.
                  </p>
                </motion.div>

                {/* Metadata */}
                <div className="mt-8 grid max-w-2xl grid-cols-2 gap-5 sm:grid-cols-4">
                  {[
                    ["Stack", "React + TS"],
                    ["Status", "Live"],
                    ["Platform", "Web"],
                    ["Deploy", "Netlify"],
                  ].map(([label, value], index) => (
                    <motion.div
                      key={label}
                      initial={{
                        opacity: 0,
                        y: 15,
                      }}
                      whileInView={{
                        opacity: 1,
                        y: 0,
                      }}
                      viewport={{
                        once: false,
                        amount: 0.4,
                      }}
                      transition={{
                        duration: 0.45,
                        delay: 0.3 + index * 0.07,
                      }}
                    >
                      <div className="text-[9px] uppercase tracking-[0.2em] text-zinc-700">
                        {label}
                      </div>

                      <div className="mt-2 text-xs text-zinc-400">
                        {value}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
                <motion.a
                  href="https://godsownroute.netlify.app/"
                  target="_blank"
                  rel="noreferrer"
                  whileHover={{
                    y: -3,
                    scale: 1.02,
                  }}
                  whileTap={{
                    scale: 0.98,
                  }}
                  className="flex items-center justify-center gap-3 rounded-full bg-white px-6 py-3 text-sm font-semibold text-zinc-950"
                >
                  Live Demo
                  <ExternalIcon />
                </motion.a>

                <motion.a
                  href="https://github.com/bdhananjay1213-prog/GodsownRoute"
                  target="_blank"
                  rel="noreferrer"
                  whileHover={{
                    y: -3,
                  }}
                  className="flex items-center justify-center gap-3 rounded-full border border-zinc-800 bg-zinc-900/50 px-6 py-3 text-sm font-medium text-zinc-300 transition hover:border-zinc-600 hover:text-white"
                >
                  GitHub
                  <ArrowIcon />
                </motion.a>
              </div>
            </div>

            {/* Bottom statement */}
            <div className="border-t border-zinc-900 px-7 py-5 sm:px-10">
              <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-700">
                <span className="h-1.5 w-1.5 rounded-full bg-blue-400/60" />
                <span>
                  Built from idea to deployment.
                </span>
              </div>
            </div>
          </motion.article>
        </ScrollReveal>
      </div>
    </section>
  );
}

export default Projects;