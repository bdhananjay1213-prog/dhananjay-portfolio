import { motion } from "motion/react";
import ScrollReveal from "./ScrollReveal";

function BrowserIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      className="h-5 w-5"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M3 9h18" />
      <path d="M7 6.5h.01M10 6.5h.01M13 6.5h.01" />
    </svg>
  );
}

function BrainIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      className="h-5 w-5"
    >
      <path d="M9.5 4.5a3 3 0 0 0-5 2.2 3.2 3.2 0 0 0 .4 1.5A3.4 3.4 0 0 0 3 11.3a3.3 3.3 0 0 0 2 3.1 3 3 0 0 0 4.5 3.1V5.8a3 3 0 0 0-0-1.3Z" />
      <path d="M14.5 4.5a3 3 0 0 1 5 2.2 3.2 3.2 0 0 1-.4 1.5 3.4 3.4 0 0 1 1.9 3.1 3.3 3.3 0 0 1-2 3.1 3 3 0 0 1-4.5 3.1V5.8a3 3 0 0 1 0-1.3Z" />
      <path d="M9.5 9.5h2M12 7v10M14.5 9.5h-2M7 13h2M17 13h-2" />
    </svg>
  );
}

function ServerIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      className="h-5 w-5"
    >
      <rect x="4" y="4" width="16" height="6" rx="1.5" />
      <rect x="4" y="14" width="16" height="6" rx="1.5" />
      <path d="M8 7h.01M8 17h.01M12 7h5M12 17h5" />
    </svg>
  );
}

function RocketIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      className="h-5 w-5"
    >
      <path d="M14.5 4.5c2.4-1.5 4.7-1.5 5-1.5.1.3.1 2.6-1.4 5l-5.4 5.4-3.1-3.1 4.9-5.8Z" />
      <path d="m9.6 10.4-3.8.8-2.3 2.3-.8 4.6 4.6.8 2.3-2.3.8-3.8" />
      <circle cx="15.8" cy="7.2" r="1.2" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      className="h-4 w-4"
    >
      <path d="M5 12h13" />
      <path d="m13 6 6 6-6 6" />
    </svg>
  );
}

/* -------------------------------------------------------------------------- */
/* WEB DEVELOPMENT                                                            */
/* -------------------------------------------------------------------------- */

function WebVisual() {
  return (
    <div className="relative h-full overflow-hidden">
      {/* Browser */}
      <motion.div
        initial={{ opacity: 0, x: -35, scale: 0.94 }}
        whileInView={{ opacity: 1, x: 0, scale: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.8,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute left-[7%] top-[18%] w-[55%] overflow-hidden rounded-xl border border-blue-400/20 bg-zinc-950/90 shadow-2xl shadow-blue-500/10"
      >
        <div className="flex h-7 items-center gap-1.5 border-b border-zinc-800 px-3">
          <span className="h-1.5 w-1.5 rounded-full bg-red-400/60" />
          <span className="h-1.5 w-1.5 rounded-full bg-yellow-400/60" />
          <span className="h-1.5 w-1.5 rounded-full bg-green-400/60" />
          <div className="ml-3 h-3 w-24 rounded-full bg-zinc-800" />
        </div>

        <div className="flex items-center justify-between px-4 py-3">
          <div className="h-2 w-12 rounded-full bg-blue-400/50" />

          <div className="flex gap-3">
            {["Home", "About", "Projects"].map((item) => (
              <span key={item} className="text-[6px] text-zinc-600">
                {item}
              </span>
            ))}
          </div>
        </div>

        <div className="px-4 pb-4">
          <div className="relative h-20 overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-purple-500/10 to-transparent" />

            <div className="absolute left-4 top-5">
              <div className="text-[10px] font-semibold text-white">
                Build
              </div>

              <div className="mt-1 text-[5px] text-zinc-500">
                Without Limits
              </div>

              <div className="mt-3 h-3 w-12 rounded bg-blue-400/20" />
            </div>

            <motion.div
              animate={{
                x: [0, 8, 0],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute -right-5 -top-5 h-20 w-20 rounded-full bg-blue-400/10 blur-2xl"
            />
          </div>
        </div>
      </motion.div>

      {/* Code panel */}
      <motion.div
        initial={{ opacity: 0, x: 35, scale: 0.94 }}
        whileInView={{ opacity: 1, x: 0, scale: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.8,
          delay: 0.18,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute right-[6%] top-[28%] w-[42%] rounded-xl border border-blue-400/20 bg-zinc-950/95 p-4 shadow-2xl shadow-blue-500/10"
      >
        <div className="mb-3 flex items-center justify-between">
          <span className="text-[7px] text-zinc-600">
            App.tsx
          </span>

          <span className="text-[6px] text-blue-400/60">
            React
          </span>
        </div>

        <div className="space-y-1 font-mono text-[6px] leading-3">
          <div className="text-purple-400">
            export default function App()
          </div>

          <div className="text-zinc-600">{"{"}</div>

          <div className="pl-2 text-blue-300">
            return (
          </div>

          <div className="pl-4 text-cyan-400">
            &lt;div className="app"&gt;
          </div>

          <div className="pl-6 text-zinc-500">
            &lt;h1&gt;Build&lt;/h1&gt;
          </div>

          <div className="pl-6 text-zinc-500">
            &lt;p&gt;Ideas to reality&lt;/p&gt;
          </div>

          <div className="pl-4 text-cyan-400">
            &lt;/div&gt;
          </div>

          <div className="pl-2 text-blue-300">
            );
          </div>

          <div className="text-zinc-600">
            {"}"}
          </div>
        </div>
      </motion.div>

      {/* Floating badge */}
      <motion.div
        initial={{ opacity: 0, y: -15, scale: 0.85 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.6,
          delay: 0.4,
        }}
        animate={{
          y: [-2, -7, -2],
        }}
        className="absolute right-[5%] top-[8%] rounded-lg border border-blue-400/20 bg-zinc-950/90 px-3 py-2 shadow-lg"
      >
        <div className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.8)]" />

          <div>
            <div className="text-[6px] text-zinc-400">
              Responsive
            </div>

            <div className="text-[6px] text-zinc-600">
              Modern • Fast
            </div>
          </div>
        </div>
      </motion.div>

      <div className="absolute left-1/3 top-1/2 h-32 w-32 rounded-full bg-blue-500/10 blur-3xl" />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* AI INTEGRATION                                                             */
/* -------------------------------------------------------------------------- */

function AIVisual() {
  const inputs = [
    ["User Input", "◉"],
    ["Documents", "▣"],
    ["Real-time Data", "◈"],
  ];

  const outputs = [
    ["Smart Responses", "◌"],
    ["Automations", "⚙"],
    ["Insights", "▥"],
  ];

  return (
    <div className="relative h-full overflow-hidden">
      {/* Inputs */}
      <div className="absolute left-[5%] top-1/2 -translate-y-1/2 space-y-3">
        {inputs.map(([label, icon], index) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, x: -25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.35 }}
            transition={{
              duration: 0.55,
              delay: index * 0.1,
              ease: "easeOut",
            }}
            className="flex items-center gap-2 rounded-lg border border-purple-400/15 bg-zinc-950/80 px-3 py-2"
          >
            <span className="text-[8px] text-purple-300">
              {icon}
            </span>

            <span className="whitespace-nowrap text-[7px] text-zinc-500">
              {label}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Input connector */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{ duration: 0.6, delay: 0.25 }}
        className="absolute left-[28%] top-1/2 h-px w-[17%] origin-left bg-gradient-to-r from-purple-400/20 to-purple-400/60"
      />

      {/* AI core */}
      <motion.div
        initial={{
          opacity: 0,
          scale: 0.5,
        }}
        whileInView={{
          opacity: 1,
          scale: 1,
        }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.8,
          delay: 0.25,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute left-1/2 top-1/2 flex h-24 w-24 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full border border-purple-400/30 bg-purple-500/10 shadow-[0_0_45px_rgba(168,85,247,0.2)]"
      >
        <motion.div
          animate={{
            scale: [1, 1.12, 1],
          }}
          transition={{
            duration: 2.8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="text-purple-300"
        >
          <BrainIcon />
        </motion.div>

        <span className="mt-1 text-[9px] font-semibold tracking-widest text-purple-200">
          AI
        </span>
      </motion.div>

      {/* Orbit */}
      <motion.div
        animate={{
          rotate: 360,
        }}
        transition={{
          duration: 14,
          repeat: Infinity,
          ease: "linear",
        }}
        className="absolute left-1/2 top-1/2 h-32 w-32 -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-purple-400/20"
      />

      {/* Output connector */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{ duration: 0.6, delay: 0.55 }}
        className="absolute right-[27%] top-1/2 h-px w-[17%] origin-left bg-gradient-to-r from-purple-400/60 to-purple-400/20"
      />

      {/* Outputs */}
      <div className="absolute right-[5%] top-1/2 -translate-y-1/2 space-y-3">
        {outputs.map(([label, icon], index) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, x: 25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.35 }}
            transition={{
              duration: 0.55,
              delay: 0.55 + index * 0.1,
              ease: "easeOut",
            }}
            className="flex items-center gap-2 rounded-lg border border-purple-400/15 bg-zinc-950/80 px-3 py-2"
          >
            <span className="text-[8px] text-purple-300">
              {icon}
            </span>

            <span className="whitespace-nowrap text-[7px] text-zinc-500">
              {label}
            </span>
          </motion.div>
        ))}
      </div>

      <div className="absolute bottom-[9%] left-1/2 -translate-x-1/2 whitespace-nowrap text-[7px] tracking-wider text-zinc-600">
        LLMs&nbsp;&nbsp;•&nbsp;&nbsp;APIs&nbsp;&nbsp;•&nbsp;&nbsp;Real Applications
      </div>

      <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-purple-500/10 blur-3xl" />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* BACKEND & APIs                                                             */
/* -------------------------------------------------------------------------- */

function BackendVisual() {
  return (
    <div className="relative h-full overflow-hidden">
      {/* Frontend */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.7,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute left-[5%] top-1/2 w-[25%] -translate-y-1/2 rounded-xl border border-emerald-400/20 bg-zinc-950/90 p-4"
      >
        <div className="mb-2 flex items-center gap-2">
          <BrowserIcon />

          <span className="text-[8px] font-medium text-zinc-300">
            Frontend
          </span>
        </div>

        <div className="text-[6px] leading-3 text-zinc-600">
          Web / Mobile App
        </div>
      </motion.div>

      {/* Frontend → API */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.5,
          delay: 0.25,
        }}
        className="absolute left-[29%] top-1/2 h-px w-[13%] origin-left bg-emerald-400/50"
      />

      {/* API */}
      <motion.div
        initial={{
          opacity: 0,
          scale: 0.7,
        }}
        whileInView={{
          opacity: 1,
          scale: 1,
        }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.7,
          delay: 0.2,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute left-1/2 top-1/2 flex h-24 w-[25%] -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-xl border border-emerald-400/30 bg-emerald-500/[0.04] shadow-[0_0_35px_rgba(52,211,153,0.08)]"
      >
        <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-400/20 bg-emerald-400/10">
          <ServerIcon />
        </div>

        <span className="text-[9px] font-semibold text-emerald-300">
          API
        </span>

        <span className="mt-1 text-[6px] text-zinc-600">
          Fast • Secure • Scalable
        </span>
      </motion.div>

      {/* API → Database */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.5,
          delay: 0.5,
        }}
        className="absolute right-[29%] top-1/2 h-px w-[13%] origin-left bg-emerald-400/50"
      />

      {/* Database */}
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.7,
          delay: 0.5,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="absolute right-[5%] top-1/2 w-[25%] -translate-y-1/2 rounded-xl border border-emerald-400/20 bg-zinc-950/90 p-4"
      >
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg border border-emerald-400/15">
            <span className="text-xs text-emerald-300">
              ◉
            </span>
          </div>

          <span className="text-[8px] font-medium text-zinc-300">
            Database
          </span>
        </div>

        <div className="text-[6px] leading-3 text-zinc-600">
          Store • Manage • Scale
        </div>
      </motion.div>

      {/* Stack */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.6,
          delay: 0.7,
        }}
        className="absolute bottom-[9%] left-1/2 flex -translate-x-1/2 gap-2"
      >
        {["</>", "Python", "FastAPI", "MySQL"].map((item) => (
          <span
            key={item}
            className="rounded-md border border-emerald-400/10 bg-emerald-400/[0.04] px-2 py-1 text-[6px] text-emerald-300/60"
          >
            {item}
          </span>
        ))}
      </motion.div>

      <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/5 blur-3xl" />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* DEPLOYMENT                                                                 */
/* -------------------------------------------------------------------------- */

function DeploymentVisual() {
  const steps = [
    ["Code", "</>"],
    ["GitHub", "●"],
    ["Build", "⚙"],
    ["Cloud", "☁"],
    ["Live", "◉"],
  ];

  return (
    <div className="relative h-full overflow-hidden">
      <div className="absolute left-[7%] right-[7%] top-1/2 -translate-y-1/2">
        <div className="absolute left-0 right-0 top-7 h-px bg-gradient-to-r from-orange-400/10 via-orange-400/50 to-orange-400/10" />

        <div className="relative flex items-start justify-between">
          {steps.map(([label, icon], index) => (
            <motion.div
              key={label}
              initial={{
                opacity: 0,
                y: 20,
                scale: 0.85,
              }}
              whileInView={{
                opacity: 1,
                y: 0,
                scale: 1,
              }}
              viewport={{
                once: false,
                amount: 0.35,
              }}
              transition={{
                duration: 0.55,
                delay: index * 0.12,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="relative flex w-14 flex-col items-center"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-orange-400/20 bg-zinc-950">
                <motion.span
                  animate={{
                    opacity: [0.45, 1, 0.45],
                  }}
                  transition={{
                    duration: 2.5,
                    delay: index * 0.35,
                    repeat: Infinity,
                  }}
                  className="text-sm text-orange-300/70"
                >
                  {icon}
                </motion.span>
              </div>

              <span className="mt-2 text-[7px] font-medium text-zinc-400">
                {label}
              </span>

              <span className="mt-1 whitespace-nowrap text-[5px] text-zinc-700">
                {index === 0
                  ? "Push changes"
                  : index === 1
                    ? "Version control"
                    : index === 2
                      ? "CI / CD"
                      : index === 3
                        ? "Deploy"
                        : "On the web"}
              </span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Traveling deployment signal */}
      <motion.div
        initial={{ left: "8%", opacity: 0 }}
        whileInView={{
          left: "92%",
          opacity: [0, 1, 1, 0],
        }}
        viewport={{
          once: false,
          amount: 0.35,
        }}
        transition={{
          duration: 3.2,
          delay: 0.65,
          ease: "linear",
        }}
        className="absolute top-[calc(50%+6px)] h-1.5 w-1.5 rounded-full bg-orange-300 shadow-[0_0_15px_rgba(251,146,60,0.9)]"
      />

      {/* Success */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.35 }}
        transition={{
          duration: 0.6,
          delay: 1.1,
        }}
        className="absolute bottom-[8%] left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-emerald-400/15 bg-emerald-400/[0.04] px-4 py-2"
      >
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]" />

        <span className="whitespace-nowrap text-[7px] text-emerald-300/70">
          Deployed Successfully!
        </span>
      </motion.div>

      <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-orange-500/5 blur-3xl" />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* SERVICES                                                                   */
/* -------------------------------------------------------------------------- */

const services = [
  {
    number: "01",
    title: "Web Development",
    description:
      "Modern interfaces built to look sharp and work smoothly.",
    tags: ["React", "TypeScript", "Tailwind"],
    icon: <BrowserIcon />,
    accent: "blue",
  },
  {
    number: "02",
    title: "AI Integration",
    description:
      "Practical AI features connected to real applications.",
    tags: ["LLMs", "AI APIs", "Automation"],
    icon: <BrainIcon />,
    accent: "purple",
  },
  {
    number: "03",
    title: "Backend & APIs",
    description:
      "Reliable APIs, databases, and application logic.",
    tags: ["Python", "FastAPI", "MySQL"],
    icon: <ServerIcon />,
    accent: "emerald",
  },
  {
    number: "04",
    title: "Deployment",
    description:
      "From localhost to a live product on the web.",
    tags: ["GitHub", "Netlify", "Cloud"],
    icon: <RocketIcon />,
    accent: "orange",
  },
];

function Services() {
  return (
    <section
      id="services"
      className="relative overflow-hidden bg-zinc-950 px-6 py-32 text-white"
    >
      <div className="pointer-events-none absolute inset-0 opacity-[0.035]">
        <div
          className="h-full w-full"
          style={{
            backgroundImage:
              "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
            backgroundSize: "70px 70px",
          }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl">
        <ScrollReveal
          delay={0.1}
          distance={50}
          className="mx-auto mb-20 max-w-3xl text-center"
        >
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/70 px-4 py-2">
            <motion.span
              animate={{
                opacity: [0.4, 1, 0.4],
                scale: [1, 1.25, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
              className="h-1.5 w-1.5 rounded-full bg-purple-400 shadow-[0_0_10px_rgba(192,132,252,0.8)]"
            />

            <span className="text-[10px] font-medium uppercase tracking-[0.3em] text-zinc-500">
              Services
            </span>
          </div>

          <h2 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
            I turn ideas into

            <span className="block bg-gradient-to-r from-purple-300 via-blue-300 to-cyan-300 bg-clip-text text-transparent">
              working products.
            </span>
          </h2>

          <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-zinc-500 sm:text-lg">
            From interface to infrastructure, I build the pieces that make
            digital products work.
          </p>
        </ScrollReveal>

        <div className="grid gap-6 md:grid-cols-2">
          {services.map((service, index) => (
            <ScrollReveal
              key={service.number}
              delay={index * 0.08}
              distance={60}
            >
              <motion.article
                whileHover={{
                  y: -7,
                }}
                transition={{
                  duration: 0.3,
                }}
                className={`group relative overflow-hidden rounded-3xl border bg-zinc-900/40 backdrop-blur-xl ${
                  service.accent === "blue"
                    ? "border-blue-400/10 hover:border-blue-400/25"
                    : service.accent === "purple"
                      ? "border-purple-400/10 hover:border-purple-400/25"
                      : service.accent === "emerald"
                        ? "border-emerald-400/10 hover:border-emerald-400/25"
                        : "border-orange-400/10 hover:border-orange-400/25"
                }`}
              >
                <div
                  className={`relative h-[300px] border-b ${
                    service.accent === "blue"
                      ? "border-blue-400/10 bg-blue-500/[0.025]"
                      : service.accent === "purple"
                        ? "border-purple-400/10 bg-purple-500/[0.025]"
                        : service.accent === "emerald"
                          ? "border-emerald-400/10 bg-emerald-500/[0.025]"
                          : "border-orange-400/10 bg-orange-500/[0.025]"
                  }`}
                >
                  <div className="absolute left-6 top-6 z-20">
                    <span className="rounded-full border border-zinc-800 bg-zinc-950/80 px-3 py-1 text-[10px] font-medium text-zinc-500 backdrop-blur-xl">
                      {service.number}
                    </span>
                  </div>

                  {service.number === "01" && <WebVisual />}
                  {service.number === "02" && <AIVisual />}
                  {service.number === "03" && <BackendVisual />}
                  {service.number === "04" && <DeploymentVisual />}
                </div>

                <div className="relative p-7">
                  <div className="flex items-start justify-between gap-5">
                    <div className="flex items-start gap-4">
                      <div
                        className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
                          service.accent === "blue"
                            ? "border-blue-400/20 bg-blue-400/10 text-blue-300"
                            : service.accent === "purple"
                              ? "border-purple-400/20 bg-purple-400/10 text-purple-300"
                              : service.accent === "emerald"
                                ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-300"
                                : "border-orange-400/20 bg-orange-400/10 text-orange-300"
                        }`}
                      >
                        {service.icon}
                      </div>

                      <div>
                        <h3 className="text-xl font-semibold tracking-tight sm:text-2xl">
                          {service.title}
                        </h3>

                        <p className="mt-2 max-w-md text-sm leading-6 text-zinc-500">
                          {service.description}
                        </p>
                      </div>
                    </div>

                    <motion.div
                      whileHover={{
                        rotate: 45,
                        scale: 1.1,
                      }}
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-zinc-800 text-zinc-500 transition-colors group-hover:border-zinc-600 group-hover:text-white"
                    >
                      <ArrowIcon />
                    </motion.div>
                  </div>

                  <div className="mt-6 flex flex-wrap gap-2">
                    {service.tags.map((tag) => (
                      <span
                        key={tag}
                        className={`rounded-full border px-3 py-1.5 text-[10px] ${
                          service.accent === "blue"
                            ? "border-blue-400/10 bg-blue-400/[0.04] text-blue-300/60"
                            : service.accent === "purple"
                              ? "border-purple-400/10 bg-purple-400/[0.04] text-purple-300/60"
                              : service.accent === "emerald"
                                ? "border-emerald-400/10 bg-emerald-400/[0.04] text-emerald-300/60"
                                : "border-orange-400/10 bg-orange-400/[0.04] text-orange-300/60"
                        }`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div
                  className={`pointer-events-none absolute -bottom-24 -right-24 h-48 w-48 rounded-full blur-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100 ${
                    service.accent === "blue"
                      ? "bg-blue-500/10"
                      : service.accent === "purple"
                        ? "bg-purple-500/10"
                        : service.accent === "emerald"
                          ? "bg-emerald-500/10"
                          : "bg-orange-500/10"
                  }`}
                />
              </motion.article>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Services;