import { motion } from "motion/react";   //used for overall animation

function Contact() {
  return (
    <section
      id="contact"
      className="relative overflow-hidden border-t border-zinc-800 bg-zinc-950 px-6 py-32 text-white"
    >
      {/* Background grid */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.025] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:80px_80px]" />

      {/* Main ambient glow */}
      <motion.div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-purple-500/10 blur-3xl"
        animate={{
          scale: [1, 1.12, 1],
          opacity: [0.25, 0.45, 0.25],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="relative mx-auto max-w-7xl">

        {/* Main CTA */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-900/30 px-6 py-20 text-center sm:px-12 sm:py-28"
        >
          {/* Card glow */}
          <div className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-blue-500/10 blur-3xl" />

          {/* Availability */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="relative mb-8 inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/5 px-4 py-2"
          >
            <motion.span
              animate={{
                opacity: [1, 0.4, 1],
                scale: [1, 0.8, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
              className="h-2 w-2 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/50"
            />

            <span className="text-xs uppercase tracking-[0.2em] text-emerald-400/80">
              Available for freelance work
            </span>
          </motion.div>

          {/* Heading */}
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              delay: 0.3,
              duration: 0.8,
            }}
            className="relative mx-auto max-w-5xl text-5xl font-bold leading-[1.05] tracking-tight sm:text-7xl lg:text-8xl"
          >
            Have an idea?
            <span className="block bg-gradient-to-r from-white via-zinc-300 to-zinc-600 bg-clip-text text-transparent">
              Let's build it.
            </span>
          </motion.h2>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              delay: 0.5,
              duration: 0.7,
            }}
            className="relative mx-auto mt-8 max-w-2xl text-lg leading-8 text-zinc-500 sm:text-xl"
          >
            Need a website, web application, backend API, or AI-powered
            solution? Tell me what you're working on and let's turn the idea
            into something real.
          </motion.p>

          {/* Primary CTA */}
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              delay: 0.7,
              duration: 0.6,
            }}
            className="relative mt-10"
          >
            {/* IMPORTANT: replace YOUR_EMAIL with your actual email */}
            <motion.a
              href="mailto:YOUR_EMAIL"
              whileHover={{
                scale: 1.04,
                y: -4,
              }}
              whileTap={{
                scale: 0.97,
              }}
              className="group inline-flex items-center gap-3 rounded-full bg-white px-7 py-4 text-sm font-semibold text-zinc-950 shadow-2xl shadow-white/10"
            >
              Start a conversation

              <motion.span
                animate={{ x: [0, 4, 0] }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                }}
              >
                ↗
              </motion.span>
            </motion.a>
          </motion.div>
        </motion.div>

        {/* Contact links */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{
            delay: 0.3,
            duration: 0.6,
          }}
          className="mt-8 grid gap-4 sm:grid-cols-2"
        >
          {/* Email */}
          <motion.a
            href="mailto:YOUR_EMAIL"
            whileHover={{ y: -5 }}
            whileTap={{ scale: 0.98 }}
            className="group relative overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/20 p-6 transition-all duration-300 hover:border-zinc-600 hover:bg-zinc-900/50"
          >
            <div className="pointer-events-none absolute -right-20 -top-20 h-40 w-40 rounded-full bg-blue-500/10 blur-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

            <div className="relative">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.2em] text-zinc-600">
                  Email
                </span>

                <span className="text-zinc-600 transition-colors group-hover:text-white">
                  ↗
                </span>
              </div>

              <p className="mt-5 text-xl font-semibold text-zinc-200">
                Let's talk about your idea.
              </p>

              <p className="mt-2 text-sm text-zinc-600">
                Have a project in mind? Send me a message.
              </p>

              <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-zinc-700 bg-zinc-950 px-4 py-2.5 text-sm font-medium text-zinc-300 transition-all duration-300 group-hover:border-zinc-500 group-hover:bg-white group-hover:text-zinc-950">
                Send me an email

                <motion.span
                  animate={{ x: [0, 3, 0] }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                  }}
                >
                  →
                </motion.span>
              </div>
            </div>
          </motion.a>

          {/* GitHub */}
          <motion.a
            href="https://github.com/dhanjz1213-max/dhananjay-dev"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ y: -5 }}
            whileTap={{ scale: 0.98 }}
            className="group relative overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/20 p-6 transition-all duration-300 hover:border-zinc-600 hover:bg-zinc-900/50"
          >
            <div className="pointer-events-none absolute -right-20 -top-20 h-40 w-40 rounded-full bg-purple-500/10 blur-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

            <div className="relative">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.2em] text-zinc-600">
                  GitHub
                </span>

                <span className="text-zinc-600 transition-colors group-hover:text-white">
                  ↗
                </span>
              </div>

              <p className="mt-5 text-xl font-semibold text-zinc-200">
                See what I'm building.
              </p>

              <p className="mt-2 text-sm text-zinc-600">
                Explore my projects and development work.
              </p>

              <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-zinc-700 bg-zinc-950 px-4 py-2.5 text-sm font-medium text-zinc-300 transition-all duration-300 group-hover:border-zinc-500 group-hover:bg-white group-hover:text-zinc-950">
                View GitHub

                <motion.span
                  animate={{ x: [0, 3, 0] }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    delay: 0.2,
                  }}
                >
                  →
                </motion.span>
              </div>
            </div>
          </motion.a>
        </motion.div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{
            delay: 0.4,
            duration: 0.7,
          }}
          className="mt-20 border-t border-zinc-900 pt-8"
        >
          <div className="flex flex-col justify-between gap-4 text-xs text-zinc-600 sm:flex-row sm:items-center">
            <p>
              © 2026 Dhananjay. Built with React & TypeScript.
            </p>

            <div className="flex items-center gap-3">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              <span>Available for freelance work</span>
            </div>
          </div>
        </motion.footer>
      </div>
    </section>
  );
}

export default Contact;