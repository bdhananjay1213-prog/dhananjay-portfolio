import { motion } from "motion/react";

interface SectionTransitionProps {
  from?: "purple" | "blue" | "cyan";
}

function SectionTransition({
  from = "purple",
}: SectionTransitionProps) {
  const glow =
    from === "blue"
      ? "bg-blue-500"
      : from === "cyan"
        ? "bg-cyan-400"
        : "bg-purple-500";  

  const line =
    from === "blue"
      ? "from-transparent via-blue-400/30 to-transparent"
      : from === "cyan"
        ? "from-transparent via-cyan-400/30 to-transparent"
        : "from-transparent via-purple-400/30 to-transparent";

  return (
    <div className="relative h-32 overflow-hidden bg-zinc-950">
      {/* Main atmospheric glow */}
      <motion.div
        animate={{
          x: ["-20%", "20%", "-20%"],
          scale: [1, 1.15, 1],
          opacity: [0.25, 0.45, 0.25],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className={`absolute left-1/2 top-1/2 h-32 w-[55%] -translate-x-1/2 -translate-y-1/2 rounded-full ${glow}/10 blur-[80px]`}
      />

      {/* Secondary glow */}
      <motion.div
        animate={{
          x: ["20%", "-20%", "20%"],
          opacity: [0.1, 0.3, 0.1],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className={`absolute left-1/2 top-1/2 h-20 w-[25%] -translate-x-1/2 -translate-y-1/2 rounded-full ${glow}/10 blur-[60px]`}
      />

      {/* Energy line */}
      <div className="absolute left-1/2 top-1/2 w-full -translate-x-1/2">
        <div
          className={`h-px w-full bg-gradient-to-r ${line}`}
        />
      </div>

      {/* Moving signal */}
      <motion.div
        animate={{
          left: ["15%", "85%"],
          opacity: [0, 1, 1, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "linear",
        }}
        className={`absolute top-1/2 h-1 w-1 -translate-y-1/2 rounded-full ${glow} shadow-[0_0_14px_currentColor]`}
      />

      {/* Tiny particles */}
      <motion.span
        animate={{
          y: [0, -12, 0],
          opacity: [0.1, 0.5, 0.1],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
        }}
        className="absolute left-[27%] top-[35%] h-1 w-1 rounded-full bg-white"
      />

      <motion.span
        animate={{
          y: [0, 10, 0],
          opacity: [0.1, 0.4, 0.1],
        }}
        transition={{
          duration: 5,
          delay: 1,
          repeat: Infinity,
        }}
        className="absolute right-[29%] top-[60%] h-1 w-1 rounded-full bg-white"
      />

      {/* Fade edges */}
      <div className="absolute inset-x-0 top-0 h-12 bg-gradient-to-b from-zinc-950 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-zinc-950 to-transparent" />
    </div>
  );
}

export default SectionTransition;