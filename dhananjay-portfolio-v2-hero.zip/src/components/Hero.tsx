import { motion, useScroll, useSpring, useTransform } from "motion/react";
import { useRef } from "react";

const techStack = ["React", "TypeScript", "Python", "AI", "APIs"];

function Hero() {
  const heroRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  const progress = useSpring(scrollYProgress, {
    stiffness: 90,
    damping: 24,
    mass: 0.35,
  });

  const titleY = useTransform(progress, [0, 0.72], [0, -150]);
  const titleScale = useTransform(progress, [0, 0.72], [1, 0.78]);
  const titleOpacity = useTransform(progress, [0, 0.58], [1, 0]);
  const visualY = useTransform(progress, [0, 0.8], [0, -95]);
  const visualScale = useTransform(progress, [0, 0.8], [1, 1.12]);
  const visualOpacity = useTransform(progress, [0, 0.72], [1, 0.2]);
  const gridOpacity = useTransform(progress, [0, 0.7], [0.18, 0]);
  const orbScale = useTransform(progress, [0, 0.65], [1, 1.8]);
  const orbOpacity = useTransform(progress, [0, 0.7], [0.28, 0]);

  return (
    <section ref={heroRef} id="home" className="relative h-[175vh] text-white">
      <div className="sticky top-0 h-screen overflow-hidden">
        {/* Cinematic grid */}
        <motion.div
          style={{ opacity: gridOpacity }}
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.045)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.045)_1px,transparent_1px)] bg-[size:72px_72px] [mask-image:radial-gradient(circle_at_center,black,transparent_72%)]"
        />

        {/* Deep atmospheric orb */}
        <motion.div
          style={{ scale: orbScale, opacity: orbOpacity }}
          className="pointer-events-none absolute left-1/2 top-[42%] h-[38vw] w-[38vw] min-h-[300px] min-w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-purple-500/20 blur-[120px]"
        />

        {/* Edge vignette */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_28%,rgba(9,9,11,0.72)_100%)]" />

        <div className="relative z-10 mx-auto flex h-full w-full max-w-[1600px] items-center px-6 sm:px-10 lg:px-16">
          <motion.div
            style={{ y: titleY, scale: titleScale, opacity: titleOpacity }}
            className="relative w-full"
          >
            {/* Tiny top label */}
            <motion.div
              initial={{ opacity: 0, y: 14, letterSpacing: "0.12em" }}
              animate={{ opacity: 1, y: 0, letterSpacing: "0.28em" }}
              transition={{ duration: 1, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
              className="mb-7 text-[10px] font-medium uppercase text-zinc-500 sm:text-xs"
            >
              B. Dhananjay / Digital Builder
            </motion.div>

            {/* Massive editorial title */}
            <div className="max-w-6xl">
              <motion.h1
                initial={{ opacity: 0, y: 55, filter: "blur(18px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ duration: 1.15, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="font-semibold leading-[0.82] tracking-[-0.075em]"
              >
                <span className="block text-[clamp(4.5rem,13vw,12rem)]">DHANJAY</span>
                <span className="mt-2 block pl-[7vw] text-[clamp(3rem,8.5vw,8rem)] text-zinc-500 sm:mt-4">
                  BUILDS.
                </span>
              </motion.h1>

              <motion.div
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
                className="mt-9 flex max-w-2xl flex-col gap-6 pl-[7vw] sm:flex-row sm:items-end sm:gap-12"
              >
                <p className="max-w-lg text-sm leading-6 text-zinc-500 sm:text-base">
                  Modern web applications, APIs, and AI-powered experiences — turning ideas into products that are fast, functional, and built to ship.
                </p>

                <div className="flex flex-wrap gap-2">
                  {techStack.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full border border-white/10 bg-white/[0.035] px-3 py-1.5 text-[10px] uppercase tracking-[0.12em] text-zinc-500 backdrop-blur-md"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Floating visual: intentionally overlaps the typography */}
          <motion.div
            style={{ y: visualY, scale: visualScale, opacity: visualOpacity }}
            initial={{ opacity: 0, scale: 0.82, rotate: -2 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1.3, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="pointer-events-none absolute right-[5%] top-[53%] hidden w-[30vw] max-w-[420px] lg:block"
          >
            <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-zinc-900/60 p-2 shadow-2xl shadow-black/60 backdrop-blur-xl">
              <div className="relative overflow-hidden rounded-[1.5rem]">
                <img
                  src="/hero-visual.png"
                  alt="Developer workspace"
                  className="block w-full object-cover grayscale-[15%]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/65 via-transparent to-white/[0.05]" />
              </div>
            </div>

            <div className="absolute -bottom-5 -left-8 rounded-full border border-white/10 bg-zinc-950/90 px-4 py-2.5 text-[10px] uppercase tracking-[0.16em] text-zinc-500 shadow-xl backdrop-blur-xl">
              Ideas → Code → Product
            </div>
          </motion.div>

          {/* Scroll cue */}
          <motion.a
            href="#services"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6, duration: 0.8 }}
            className="absolute bottom-8 left-6 flex items-center gap-4 text-[9px] uppercase tracking-[0.3em] text-zinc-600 transition-colors hover:text-zinc-300 sm:left-10 lg:left-16"
          >
            <span>Scroll to explore</span>
            <motion.span
              animate={{ y: [0, 7, 0], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              className="h-8 w-px bg-gradient-to-b from-zinc-500 to-transparent"
            />
          </motion.a>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.8, duration: 0.8 }}
            className="absolute bottom-8 right-6 hidden text-right text-[9px] uppercase tracking-[0.22em] text-zinc-700 sm:right-10 sm:block lg:right-16"
          >
            01 / Introduction
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
